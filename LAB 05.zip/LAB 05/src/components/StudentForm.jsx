import { useState } from 'react';

function StudentForm({ onAdd, students }) {
  const [name, setName] = useState('');
  const [grade, setGrade] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    const gradeNum = Number(grade);
    if (name.trim() === '') {
      setError('İsim boş olamaz.');
      return;
    }
    if (isNaN(gradeNum) || gradeNum < 0 || gradeNum > 100) {
      setError('Not 0 ile 100 arasında bir sayı olmalı.');
      return;
    }

    const nameExists = students.some(
      (student) => student.name.toLowerCase() === name.trim().toLowerCase()
    );
    if (nameExists) {
      setError('Bu isimde bir öğrenci zaten mevcut.');
      return;
    }
    
    onAdd({
      id: Date.now(),
      name: name.trim(),
      grade: gradeNum,
    });

    setName('');
    setGrade('');
  };

  return (
    <form className="student-form" onSubmit={handleSubmit}>
      <input
        type="text"
        className="input"
        placeholder="Öğrenci Adı"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <input
        type="number"
        className="input input-grade"
        placeholder="Not"
        value={grade}
        onChange={(e) => setGrade(e.target.value)}
      />
      <button type="submit" className="btn">
        Öğrenci Ekle
      </button>
      {error && <small className="form-error">{error}</small>}
    </form>
  );
}

export default StudentForm;