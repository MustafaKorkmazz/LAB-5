import React from 'react';

function StudentControls({
  filter,
  setFilter,
  searchTerm,
  setSearchTerm,
  sortOrder,
  setSortOrder,
}) {
  const handleSortToggle = () => {
    setSortOrder(sortOrder === 'high-low' ? 'low-high' : 'high-low');
  };

  return (
    <div className="controls">
      <div className="filters">
        <button
          className={`filter-btn ${filter === 'all' ? 'active' : ''}`}
          onClick={() => setFilter('all')}
        >
          All
        </button>
        <button
          className={`filter-btn ${filter === 'pass' ? 'active' : ''}`}
          onClick={() => setFilter('pass')}
        >
          Pass
        </button>
        <button
          className={`filter-btn ${filter === 'fail' ? 'active' : ''}`}
          onClick={() => setFilter('fail')}
        >
          Fail
        </button>
      </div>

      <input
        type="text"
        className="input search"
        placeholder="Search by name"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      <button className="btn sort-btn" onClick={handleSortToggle}>
        Sort: {sortOrder === 'high-low' ? 'High > Low' : 'Low > High'}
      </button>
    </div>
  );
}

export default StudentControls;