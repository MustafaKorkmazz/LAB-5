import React from 'react';

function StudentItem({ student, onDelete }) {
  const passed = student.grade >= 60;

  const itemClasses = `student-item ${
    passed ? 'student-pass' : 'student-fail'
  }`;

  return (
    <li className={itemClasses}>
      <div>
        <span className="student-name">{student.name}</span>
        <span className="student-grade">(Grade: {student.grade})</span>
        <span className="student-status">
          {passed ? 'Pass' : 'Fail'}
        </span>
      </div>
      <button
        className="delete-btn"
        onClick={() => onDelete(student.id)}
      >
        Delete
      </button>
    </li>
  );
}

export default StudentItem;