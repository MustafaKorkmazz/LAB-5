import StudentItem from './StudentItem';

function StudentList({ students, onDelete, searchTerm }) {
  if (students.length === 0) {
    if (searchTerm) {
      return (
        <p className="no-data">
          "<em>{searchTerm}</em>" ile eşleşen öğrenci yok
        </p>
      );
    }
    return (
      <p className="no-data">
        Henüz öğrenci yok yukarıdaki formu kullanın.
      </p>
    );
  }

  return (
    <ul className="student-list">
      {students.map((student) => (
        <StudentItem
          key={student.id}
          student={student}
          onDelete={onDelete}
        />
      ))}
    </ul>
  );
}

export default StudentList;